const test = require('node:test');
const assert = require('node:assert/strict');
const path = require('node:path');

const { createInquiryStore } = require('./server');

test('inquiry store saves an inquiry and returns it', async () => {
  const dbPath = path.join(__dirname, 'tmp-inquiry-test.db');
  const store = await createInquiryStore(dbPath);

  const saved = await store.insertInquiry({
    name: 'Test User',
    phone: '9876543210',
    category: 'Iron Gate Fabrication',
    message: 'Need a custom gate for home.'
  });

  assert.equal(saved.name, 'Test User');
  assert.equal(saved.category, 'Iron Gate Fabrication');

  const inquiryList = await store.getInquiries();
  assert.ok(Array.isArray(inquiryList));
  assert.ok(inquiryList.some(item => item.phone === '9876543210'));

  await store.close();
});
