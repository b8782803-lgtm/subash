const express = require('express');
const cors = require('cors');
const sqlite3 = require('sqlite3').verbose();
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;
const DB_PATH = process.env.DB_PATH || path.join(__dirname, 'inquiries.db');

app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(__dirname));

app.get('/', (_req, res) => {
  res.sendFile(path.join(__dirname, 'magesh.html'));
});

function createInquiryStore(dbPath = DB_PATH) {
  return new Promise((resolve, reject) => {
    const db = new sqlite3.Database(dbPath, (err) => {
      if (err) return reject(err);

      db.run(`
        CREATE TABLE IF NOT EXISTS inquiries (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          name TEXT NOT NULL,
          phone TEXT NOT NULL,
          category TEXT NOT NULL,
          message TEXT NOT NULL,
          created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
      `, (createErr) => {
        if (createErr) return reject(createErr);

        resolve({
          insertInquiry: (inquiry) => new Promise((res, rej) => {
            const { name, phone, category, message } = inquiry;

            db.run(
              'INSERT INTO inquiries (name, phone, category, message) VALUES (?, ?, ?, ?)',
              [name, phone, category, message],
              function (insertErr) {
                if (insertErr) return rej(insertErr);

                db.get(
                  'SELECT * FROM inquiries WHERE id = ?',
                  [this.lastID],
                  (getErr, row) => {
                    if (getErr) return rej(getErr);
                    res(row);
                  }
                );
              }
            );
          }),
          getInquiries: () => new Promise((res, rej) => {
            db.all('SELECT * FROM inquiries ORDER BY created_at DESC', (err, rows) => {
              if (err) return rej(err);
              res(rows);
            });
          }),
          close: () => new Promise((res, rej) => {
            db.close((err) => {
              if (err) return rej(err);
              res();
            });
          })
        });
      });
    });
  });
}

async function startServer() {
  const store = await createInquiryStore();

  app.post('/api/inquiries', async (req, res) => {
    try {
      const { name, phone, category, message } = req.body || {};

      if (!name || !phone || !category || !message) {
        return res.status(400).json({ error: 'Name, phone, category, and message are required.' });
      }

      const saved = await store.insertInquiry({ name, phone, category, message });
      return res.status(201).json({ success: true, inquiry: saved });
    } catch (error) {
      console.error('Error saving inquiry:', error);
      return res.status(500).json({ error: 'Failed to save inquiry.' });
    }
  });

  app.get('/api/inquiries', async (_req, res) => {
    try {
      const inquiries = await store.getInquiries();
      res.json(inquiries);
    } catch (error) {
      console.error('Error fetching inquiries:', error);
      res.status(500).json({ error: 'Failed to fetch inquiries.' });
    }
  });

  app.get('/health', (_req, res) => {
    res.json({ status: 'ok' });
  });

  app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${3000}`);
  });
}

if (require.main === module) {
  startServer().catch((error) => {
    console.error('Failed to start server:', error);
    process.exit(1);
  });
}

module.exports = { createInquiryStore, app };
